LOCALIZATION EXAMPLE: REPRODUCING THE SEVEN-STATION EXPERIMENT

This module replaces the historical thirteen-station example with the supplied
localization_package(1).zip experiment. The numerical localization algorithms
and parameter values are retained. Generated picks, results, figures and caches
are stored outside the released code directory.

Included source inputs
- inputs/waveforms/: Seven unchanged vertical-component waveform records of the
  event labelled small landslide on 9 June 2025 around 22:01:52 UTC. Every file
  matches the corresponding record in the released small_landslide directory.
- inputs/stations.csv: The supplied 36-station table. The seven event stations
  are selected by identifier; remaining rows provide the original table context.
- inputs/XJD2_updated.txt: The unchanged 6,760-row velocity model (X, Y, Z in
  metres and Vs in km/s). Its SHA-256 is recorded in provenance.json.

Scripts
- make_inputs1.py: Band-pass filter and AIC onset picking; generates station
  coordinates, relative arrivals, a pick report and input hashes.
- loc_xjd2.py: Velocity-grid loading, station-centred FMM travel-time fields,
  grid-search initialization and Levenberg-Marquardt localization. Unused
  standalone plotting functions and the alternative demo entry point were
  removed; the numerical functions are unchanged.
- run_localization_example.py: Released-model and homogeneous-velocity
  solutions, leave-one-station-out sensitivity, summary and Figure 5c/d panels.
- test_loc_xjd2.py: Derivative consistency, Jacobian rank and synthetic-source
  recovery diagnostics supplied with the experiment.
- reproduction_io.py: Output paths, input-row consistency and file hashes.
- plot_velocity_slices.py: Retained velocity-model visualization script from
  the prior release; it uses the same unchanged model and pyproj dependency.

Environment and commands
Use Python 3.11 or newer. The following dependency versions were verified
together with Python 3.12.14. Run these commands from the code-dataset directory
in a fresh virtual environment:

  python -m pip install -r 05_velocity_localization/requirements.txt
  python 05_velocity_localization/make_inputs1.py --out-dir ../localization_reproduction/inputs
  python 05_velocity_localization/run_localization_example.py --inputs ../localization_reproduction/inputs --out-dir ../localization_reproduction/results
  python 05_velocity_localization/test_loc_xjd2.py --inputs ../localization_reproduction/inputs

To regenerate picks directly from the full released dataset, replace the
second command with:

  python 05_velocity_localization/make_inputs1.py --records "../dataset/classified event-level waveform data/small_landslide" --out-dir ../localization_reproduction/inputs

Optional velocity sections:

  python 05_velocity_localization/plot_velocity_slices.py --out ../localization_reproduction/velocity_sections

Only the bundled or otherwise trusted waveform files should be loaded: their
NumPy dictionary format uses allow_pickle=True. Generated numeric arrays use
allow_pickle=False. Paths are resolved independently of the script location;
explicit output directories keep generated files outside code-dataset/dataset.
Changing the working directory requires adapting the relative example paths.

Generated files
The inputs directory contains stas_xyz.npy, tobs_p.npy, pick_report.csv and
input_provenance.json. The results directory contains localization_summary.json,
reproduction_metadata.json, fig5-c.pdf, fig5-d.pdf and PNG previews. Rerunning
the commands overwrites files in the chosen output directories. Read the
console diagnostics as well as the result summary.

Expected numerical reference
Seven stations pass SNR >= 3. Picks span 0.552 s. Stations in arrival order:
230000086, 230000120, 230000116, 230000087, 230000085, 230000112, 230000119.

Released velocity model:
  XYZ = (392.2747, 4865.9422, 0.1592) km; t0 = -0.3975 s; RMS = 0.0569 s.
Homogeneous velocity:
  XYZ = (392.4947, 4865.9710, 0.2162) km; Vp = 0.491 km/s;
  t0 = -0.2400 s; RMS = 0.0023 s.
The two locations differ by 229 m. Station jackknife maximum shifts are
0 m (released model) and 35 m (homogeneous model), rounded as in the source.

Method and interpretation
1. Records contain 2,499 or 2,500 samples at approximately 250 Hz, starting two seconds before their
   event_start trigger time. Filtering is fourth-order, zero-phase 2-20 Hz.
   AIC picks use the 1.0-3.5 s record window, retaining SNR >= 3. Absolute picks
   are event_start minus 2 s plus the sample offset; arrivals are relative to
   the earliest retained pick.
2. Coordinates are retained from the supplied station CSV. Z is elevation in
   kilometres, positive upwards. The model X coordinate has its 32,000,000 m
   offset removed before conversion to kilometres. The source package describes
   EPSG:4541 and fixed station-coordinate shifts of -1.79 m east and +85.86 m
   north; those frame assumptions have not been independently re-established.
3. Vs is multiplied by sqrt(3) to obtain Vp. Grid spacing is 0.02 km on all
   axes and padding is 0.3 km. Linear interpolation is used where available,
   with nearest-neighbour extension elsewhere. Four receivers are above the
   maximum model elevation. The source search bounds do not remove dependence
   on extended velocities along propagation paths.
4. The released-model solution uses grid search followed by LM. For this event
   LM terminates because damping becomes too large and retains the grid-search
   position; this is reproducible but does not demonstrate LM convergence.
   The homogeneous solution uses successive grid searches with quartered steps;
   it does not use LM. Both methods are kept as supplied for reproducibility.
5. A zero rounded model jackknife shift does not establish zero uncertainty.
   Residual fit and station omission sensitivity do not measure independent
   physical location accuracy. The formal covariance is a local model-based
   diagnostic. Geological interpretations from the source README are not
   independently established by these scripts.
6. Derivatives are computed numerically with half-grid central differences,
   not analytically. The supplied derivative check compares the same type of
   finite difference. Its small discrepancy confirms implementation consistency;
   it is not an independent analytic-derivative validation.
7. The fixed synthetic-source run uses 0.01 s Gaussian pick noise, seed 0, and
   the same forward and inverse model. Reference horizontal errors are median
   64 m / maximum 94 m; elevation errors median 19 m / maximum 169 m. These
   are numerical diagnostics, not validation against a known real-event source.

Provenance and archives
provenance.json records the source archive, retained files and verified versions.
Old localization scripts/inputs, original precomputed picks and example outputs,
the original README/requirements, and the full original archive are stored in
the dated localization archive beside code-dataset. They are not runtime inputs
of the released module. The archive includes an update manifest and a verification
report. Other experiment modules are unchanged.
